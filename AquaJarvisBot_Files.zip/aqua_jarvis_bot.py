import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

TOKEN = os.getenv('TOKEN')

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Привет! Я AquaJarvis 🤖\nГотов помочь вам с фильтрами воды от Aqua Pride.\nВведите /help, чтобы узнать, что я умею."
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "/start — Начать\n/help — Команды\n/faq — Частые вопросы\n/contact — Связаться с нами"
    )

async def faq(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Часто задаваемые вопросы:\n\n1. Сколько стоит фильтр?\n   — От 3 500₽, зависит от модели.\n2. Доставка?\n   — Бесплатно по городу.\n3. Гарантия?\n   — 1 год на все фильтры."
    )

async def contact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📞 Связаться с Aqua Pride:\nТелефон: +7 (900) 000-00-00\nInstagram: @aqua.pride\nСайт: aquapride.ru"
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.lower()
    if "цена" in text:
        await update.message.reply_text("Фильтры начинаются от 3 500₽. Хотите, подберу? 💧")
    elif "доставка" in text:
        await update.message.reply_text("Доставка бесплатная по городу. За пределами — уточните у менеджера.")
    elif "фильтр" in text:
        await update.message.reply_text("У нас есть фильтры под мойку, настольные и проточные. Что интересует?")
    elif "гарантия" in text:
        await update.message.reply_text("На все фильтры — гарантия 1 год. Поддержка всегда на связи.")
    else:
        await update.message.reply_text("Я вас понял! Передам менеджеру, или напишите /help для списка команд.")

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("faq", faq))
    app.add_handler(CommandHandler("contact", contact))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("🤖 AquaJarvis запущен")
    app.run_polling()
