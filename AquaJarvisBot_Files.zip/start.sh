#!/bin/bash
python aqua_jarvis_bot.py
